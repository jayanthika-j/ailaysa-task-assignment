
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../store/authSlice';
import { useNavigate, Link } from 'react-router-dom';

const Navbar = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { isAuthenticated } = useSelector((state) => state.auth);
    const wishlistItems = useSelector((state) => state.wishlist.items);

    const handleLogout = () => {
        dispatch(logout());
        navigate('/login');
    };

    if (!isAuthenticated) return null;

    return (
        <nav className="navbar">
            <div className="container navbar-content">
                <Link to="/" className="logo">ShopApp</Link>
                <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
                    <Link to="/wishlist" style={{ textDecoration: 'none', color: '#333' }}>
                        Wishlist ({wishlistItems.length})
                    </Link>
                    <button onClick={handleLogout} className="btn-secondary">Logout</button>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
