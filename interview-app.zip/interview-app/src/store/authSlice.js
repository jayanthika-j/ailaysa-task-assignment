
import { createSlice } from '@reduxjs/toolkit';
import Cookies from 'js-cookie';

const initialState = {
    token: Cookies.get('token') || null,
    isAuthenticated: !!Cookies.get('token'),
};

const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        login: (state, action) => {
            const token = 'fake-jwt-token';
            state.token = token;
            state.isAuthenticated = true;
            Cookies.set('token', token, { expires: 1 });
        },
        logout: (state) => {
            state.token = null;
            state.isAuthenticated = false;
            Cookies.remove('token');
        },
    },
});

export const { login, logout } = authSlice.actions;
export default authSlice.reducer;
