import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { login } from "../store/authSlice";
import { useNavigate } from "react-router-dom";
import "../App.css";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email && password) {
      dispatch(login({ email }));
      navigate("/");
    } else {
      alert("Please enter valid credentials");
    }
  };

  return (
    <div className="login-page">
      <div className="login-left">
        <div className="login-form-container">
          <h2 className="welcome-text">Welcome Back 👋</h2>
          <p className="sub-text">
            Today is a new day. It's your day. You shape it. <br />
            Sign in to start managing your projects.
          </p>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                placeholder="Example@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <div className="forgot-password">
              <a href="#forgot">Forgot Password?</a>
            </div>

            <button type="submit" className="btn-signin">
              Sign in
            </button>
          </form>

          <div className="copyright">© 2023 ALL RIGHTS RESERVED</div>
        </div>
      </div>
      <div className="login-right">
        <img src="/login-image.jpg" alt="Login Visual" className="login-image" />
      </div>
    </div>
  );
};

export default Login;

