
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { toggleWishlist } from '../store/wishlistSlice';

const Wishlist = () => {
    const { items } = useSelector((state) => state.wishlist);
    const dispatch = useDispatch();

    if (items.length === 0) {
        return (
            <div className="container" style={{ textAlign: 'center', marginTop: '50px' }}>
                <h2>Your Wishlist is Empty</h2>
                <Link to="/" className="btn-primary" style={{ textDecoration: 'none' }}>Browse Products</Link>
            </div>
        );
    }

    return (
        <div className="container">
            <h1>My Wishlist</h1>
            <div className="product-grid">
                {items.map((product) => (
                    <div key={product.id} className="product-card">
                        <Link to={`/products/${product.id}`} className="product-link">
                            <div className="image-wrapper">
                                <img src={product.image} alt={product.title} />
                            </div>
                            <div className="product-info">
                                <h3>{product.title}</h3>
                                <p className="price">${product.price}</p>
                            </div>
                        </Link>
                        <button
                            onClick={() => dispatch(toggleWishlist(product))}
                            className="btn-delete"
                            style={{ backgroundColor: '#ffc107', color: 'black' }} // Yellow for "Remove from Wishlist"
                        >
                            Remove
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Wishlist;
