
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { deleteProduct } from '../store/productSlice';
import { toggleWishlist } from '../store/wishlistSlice';
import api from '../services/api';

const ProductDetail = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const productFromStore = useSelector((state) =>
        state.products.items.find((p) => p.id == id)
    );

    const wishlist = useSelector((state) => state.wishlist.items);
    const [product, setProduct] = useState(productFromStore || null);

    useEffect(() => {
        if (!product) {
            api.get(`/products/${id}`).then((res) => {
                setProduct(res.data);
            }).catch(err => console.error(err));
        }
    }, [id, product]);

    const handleDelete = async () => {
        try {
            await api.delete(`/products/${id}`);
            dispatch(deleteProduct(parseInt(id)));
            alert('Product deleted!');
            navigate('/');
        } catch (error) {
            console.error(error);
        }
    };

    if (!product) return <div className="container">Loading...</div>;

    const isWishlisted = wishlist.some(item => item.id === product.id);

    return (
        <div className="container product-detail">
            <button onClick={() => navigate('/')} className="btn-back">← Back</button>
            <div className="detail-layout">
                <div className="detail-image">
                    <img src={product.image} alt={product.title} />
                </div>
                <div className="detail-info">
                    <h1>{product.title}</h1>
                    <span className="category">{product.category}</span>
                    <p className="price">${product.price}</p>
                    <p className="description">{product.description}</p>
                    {product.rating && <p className="rating">Rating: {product.rating.rate} / 5 ({product.rating.count} reviews)</p>}

                    <div style={{ display: 'flex', gap: '10px' }}>
                        <button
                            onClick={() => dispatch(toggleWishlist(product))}
                            className="btn-primary"
                            style={{ backgroundColor: isWishlisted ? '#ffc107' : '#28a745', color: 'white', marginTop: '20px', border: 'none' }}
                        >
                            {isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
                        </button>

                        <button onClick={handleDelete} className="btn-delete-large">Delete Product</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProductDetail;
