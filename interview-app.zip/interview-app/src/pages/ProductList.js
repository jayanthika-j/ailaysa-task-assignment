
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProducts, addProduct, deleteProduct } from '../store/productSlice';
import { toggleWishlist } from '../store/wishlistSlice';
import { Link } from 'react-router-dom';
import api from '../services/api';

const ProductList = () => {
    const dispatch = useDispatch();
    const { items, status } = useSelector((state) => state.products);
    const wishlist = useSelector((state) => state.wishlist.items);
    const [categoryFilter, setCategoryFilter] = useState('all');

    useEffect(() => {
        if (status === 'idle') {
            dispatch(fetchProducts());
        }
    }, [status, dispatch]);

    const handleCreateProduct = async () => {
        const newProduct = {
            title: 'New Product',
            price: 100,
            description: 'A description',
            category: 'electronics',
            image: 'https://placehold.co/150',
        };

        try {
            const response = await api.post('/products', newProduct);
            const productToAdd = { ...response.data, id: Date.now() };
            dispatch(addProduct(productToAdd));
            alert('Product created!');
        } catch (error) {
            console.error(error);
        }
    };

    const handleDelete = async (e, id) => {
        e.preventDefault();
        try {
            await api.delete(`/products/${id}`);
            dispatch(deleteProduct(id));
        } catch (error) {
            console.error(error);
        }
    };

    const isWishlisted = (id) => wishlist.some(item => item.id === id);

    // Extract unique categories from items
    const categories = ['all', ...new Set(items.map(p => p.category))];

    const filteredItems = categoryFilter === 'all'
        ? items
        : items.filter(p => p.category === categoryFilter);

    if (status === 'loading') return <div className="loading">Loading products...</div>;

    return (
        <div className="container">
            <div className="header-actions">
                <div>
                    <h1>Products</h1>
                    <select
                        value={categoryFilter}
                        onChange={(e) => setCategoryFilter(e.target.value)}
                        style={{ padding: '5px', paddingRight: '20px', fontSize: '1rem' }}
                    >
                        {categories.map(cat => (
                            <option key={cat} value={cat}>{cat.toUpperCase()}</option>
                        ))}
                    </select>
                </div>
                <button onClick={handleCreateProduct} className="btn-primary">Create Product</button>
            </div>

            <div className="product-grid">
                {filteredItems.map((product) => (
                    <div key={product.id} className="product-card">
                        <Link to={`/products/${product.id}`} className="product-link">
                            <div className="image-wrapper">
                                <img src={product.image} alt={product.title} />
                            </div>
                            <div className="product-info">
                                <h3>{product.title}</h3>
                                <p className="price">${product.price}</p>
                            </div>
                        </Link>
                        <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                            <button
                                className="btn-delete"
                                onClick={() => dispatch(toggleWishlist(product))}
                                style={{ backgroundColor: isWishlisted(product.id) ? '#ffc107' : '#28a745', border: 'none', flex: 1 }}
                            >
                                {isWishlisted(product.id) ? '♥ Saved' : '♥ Save'}
                            </button>
                            <button
                                className="btn-delete"
                                onClick={(e) => handleDelete(e, product.id)}
                                style={{ flex: 1 }}
                            >
                                Delete
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ProductList;
